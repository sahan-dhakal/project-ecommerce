@extends('backend.layout')

@section('title')

@endsection
@section('breadcrumb')
@include('backend.breadcrumb',['text'=>'Dashboard'])
@endsection

@section('content')

  <div class="row">
                           
    
    </div>
    <!--end row-->
                        

@endsection