<footer>
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3>About Us</h3>
                <p>This is a demo E-commerce website </p>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Policy</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Categories</h3>
                <ul>
                    <li><a href="#">Men's Fashion</a></li>
                    <li><a href="#">Women's Fashion</a></li>
                    <li><a href="#">Kid'S Fashion</a></li>
                    <li><a href="#">Teenage Fashion</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Want to Follow Us ?</h3>
                <ul>
                    <li><a href="#"><i class="fa-brands fa-facebook"></i> Facebook</a></li>
                    <li><a href="#"><i class="fa-brands fa-instagram"></i> Instagram</a></li>
                    <li><a href="#"><i class="fa-brands fa-tiktok"></i> TikTok</a></li>
                </ul>
            </div>
        </div> 
        <div class="footer-bottom">
            <p>&copy; 2025 ElevenAm. All rights reserved.</p>
        </div>
    </div>
</footer>