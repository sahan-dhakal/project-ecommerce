
<section class="hero-slider">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="hero-content">
                    <h1>Fashion Trend & <br>Collection</h1>
                    <p>Your trust in us will keep you ahead in your daily fashion </p>
                    <a href="#" class="btn-primary">Shop Now</a>
                </div>
            </div>
        </div>
    </div>
</section>