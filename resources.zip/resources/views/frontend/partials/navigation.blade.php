
<nav class="main-nav">
    <div class="container">
        <ul>
            <li><a href="/test">Home</a></li>
            <li><a href="#">Clothing</a>
                <ul class="nested-list">

                    <li><a href="#">Men's Clothing</a></li>
                    <li><a href="#">Women Clothing</a></li>
                    <li><a href="#">Kid's</a></li>
                </ul>
            </li>  

            <li><a href="#">Accessories</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </div>
</nav>